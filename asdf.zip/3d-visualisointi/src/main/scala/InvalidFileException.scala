package main.scala

class InvalidFileException(problem: String) extends java.lang.Exception(problem) 
